pointSolution = 10;%defining variables for use in functions
populationAmount = 100;
loopAmount = 100;
mutationAmount = 0.2;
crossoverAmount = 0.6;
population = zeros(populationAmount, pointSolution+pointSolution);
map = imbinarize(imread('random_map.bmp'));%Importing and reading map
prompt = "Please choose a selection method- 1: Roulette selection | 2: Rank selection | 3: Tournament selection ";
selectionChoice = input(prompt);
prompt = "Please select a crossover method- 1: 2-Point crossover | 2: Uniform Crossover ";
crossOverChoice = input(prompt);
prompt = "Please select a mutation method- 1: Swap mutation | 2: Bit flip mutation ";
mutationChoice = input(prompt) ;

for i = 1:populationAmount%iterating through population amount
    coordinates = [randi([1,500],1,pointSolution); randi([1,500],1,pointSolution);];%creating a random array of coordinates using set num of points, x and y
    coordinates = reshape(coordinates,1,[]);%reshaping coordinates to be readable
    population(i,1:20) = coordinates;%applying coordinates to population
    population(i, [1 2 19 20]) = [1 1 500 500];%setting first and second column to 1 and last 2 columns to 500
end

for currentLoop = 1:loopAmount%fitness calc loop
    fitnessCalc = populationSummary(population,map);%fitness calc function
    nextPopulation = zeros(populationAmount, (pointSolution+pointSolution));%create an empty array for the new population
    newPopMember = 0;%set index to 0
    while(newPopMember < populationAmount)%while not beyond bounds of population amount
        balance = fitnessCalc(:) / sum(fitnessCalc(:));%calculating the weights for chromosomes
        if(selectionChoice == 1)
        firstChromChoice = rouletteSelector(balance);%selecting first chromosome
        secondChromChoice = rouletteSelector(balance);%selecting second chromosome
        elseif(selectionChoice == 2)
        firstChromChoice = rankSelector(fitnessCalc);%selecting first chromosome
        secondChromChoice = rankSelector(fitnessCalc);%selecting second chromosome 
        elseif(selectionChoice == 3)
        firstChromChoice = tournamentSelector(fitnessCalc, population);%selecting first chromosome
        secondChromChoice = tournamentSelector(fitnessCalc, population);%selecting second chromosome
        end
        firstChrom = population(firstChromChoice,1:20);%applying these to current pop
        secondChrom = population(secondChromChoice,1:20);
        if (rand < crossoverAmount)%checking for random crossover
            if(crossOverChoice == 1)
            firstChild = firstChrom;%selecting points from above
            secondChild = secondChrom;
            firstCross = randi([2, pointSolution-2]);%choosing random crossover point
            secondCross = randi([firstCross+1,pointSolution-1]);%choosing next point
            indexCrossOne = ((firstCross - 1) + (firstCross - 1)) + 1;%getting indexes of points
            indexCrossTwo = secondCross + secondCross;
            crossOp = firstChild(indexCrossOne: indexCrossTwo);%performing crossover 
            firstChild(indexCrossOne: indexCrossTwo) = secondChild(indexCrossOne: indexCrossTwo);
            secondChild(indexCrossOne:indexCrossTwo) = crossOp;
            firstChrom = firstChild;%setting chromosomes for later use
            secondChrom = secondChild;
            elseif(crossOverChoice == 2)
             mask = randi([0, 1], 1, pointSolution); %creating a random mask to apply to chromosomes
            firstChild = firstChrom;
            secondChild = secondChrom;
            firstChild(mask == 1) = secondChrom(mask == 1);%applying masks to both chromosomes
            secondChild(mask == 1) = firstChrom(mask == 1);
            firstChrom = firstChild;%setting chromosomes for later use
            secondChrom = secondChild;
            end   
        end

        if(rand<mutationAmount)%swap mutation for first chrom
            if(mutationChoice == 1)
            swapMutation = randperm(pointSolution -2) + 1;%selecting random point
            firstSwap = swapMutation(1);%getting elements from random points
            secondSwap = swapMutation(2);
            firstSwap = (firstSwap - 1) + (firstSwap - 1) + 1;%performing swap mutation
            secondSwap = (secondSwap - 1) + (secondSwap - 1) + 1;
            swapper = firstChrom(firstSwap:firstSwap+1);%swapping first chrom
            firstChrom(firstSwap:firstSwap+1) = firstChrom(secondSwap:secondSwap+1);
            firstChrom(secondSwap:secondSwap+1) = swapper;
            elseif(mutationChoice == 2)
            firstBitMutation = randi([1, pointSolution]);%select a random point from point solution
            firstChrom(firstBitMutation) = ~firstChrom(firstBitMutation);%flip the bit at this point within the first chromosome
            secondBitMutation = randi([1, pointSolution]);%repeat for chromosome 2
            secondChrom(secondBitMutation) = ~secondChrom(secondBitMutation);  
            end
        end
        if(rand<mutationAmount)%same as above for second chrom
            if(mutationChoice == 1)
            swapMutation = randperm(pointSolution -2) + 1;
            firstSwap = swapMutation(1);
            secondSwap = swapMutation(2);
            firstSwap = (firstSwap - 1) + (firstSwap - 1) + 1;
            secondSwap = (secondSwap - 1) + (secondSwap - 1) + 1;
            swapper = secondChrom(firstSwap:firstSwap+1);
            secondChrom(firstSwap:firstSwap+1) = secondChrom(secondSwap:secondSwap+1);
            secondChrom(secondSwap:secondSwap+1) = swapper;
            elseif(mutationChoice == 2)
            firstBitMutation = randi([1, pointSolution]);%select a random point from point solution
            firstChrom(firstBitMutation) = ~firstChrom(firstBitMutation);%flip the bit at this point within the first chromosome
            secondBitMutation = randi([1, pointSolution]);%repeat for chromosome 2
            secondChrom(secondBitMutation) = ~secondChrom(secondBitMutation);  
            end
        end

        newPopMember = newPopMember+1;%incremting to next member
        nextPopulation(newPopMember,:) = firstChrom;%setting first chrom
        if(newPopMember<populationAmount)%checking if out of bounds
            newPopMember = newPopMember+1;
            nextPopulation(newPopMember,:) = secondChrom;%same as above for next chrom
        end
    end
    population = nextPopulation;%setting population to newly created pop
end

fitnessCalc = populationSummary(population,map);%functions applied to final population, work same as above
population(:,(pointSolution+pointSolution)+1) = fitnessCalc;
population = sortrows(population,(pointSolution+pointSolution)+1);
finalPath = population(end,1:(pointSolution+pointSolution));
newPath = pathFinder(finalPath);%finding final path based on final population results from above
imshow(map);%show map on screen
rectangle('Position',[1 1 size(map)-1],'EdgeColor','k');
line(newPath(:,2), newPath(:,1));%display lines/newPath on map




function fitnessCalc = populationSummary(population, map)%calculates fitness score
fitnessCalc = zeros(size(population,1), 1);%create a zero array
for i = 1:size(population,1)%iterate through population
        newPath = pathFinder(population(i,1:20));%find path based on population
        sizePath = myLength(newPath);%get size of path
        penalties = calcPennies(newPath,map);%calculate penalties of path
        fitnessCalc(i) = 1/(sizePath + penalties);%calculate fitness of current path
    end
end

function newPath = pathFinder(chromosome)
coordinates = reshape(chromosome, 2, []).';%.'%reshape coordinates so it can be used as a path
%coordinates = transpose(coordinates);
newPath = coordinates;%setting newPath to match coordinates
newPath = round(newPath);%rouding indivudal elements of path
end

function sizePath = myLength(newPath)
sizePath = 0;
for i = 1:size(newPath,1)-1%iterate through newPath
    sizePath = sizePath + norm(newPath(i,:)-newPath(i+1,:));%get the path by using norm to get a vector value from newPath
end
end

function penalties = calcPennies(newPath,map)
penalties = 0;
for i = 1:size(newPath,1)-1
    y1 = newPath(i,1);%setting x and y points along the line for each iteration
    y2 = newPath(i+1,1);
    x1 = newPath(i,2);
    x2 = newPath(i+1,2);
    [x,y] = bresLine(x1,x2,y1,y2);%calculate bres line based on points
    for z = 1:length(x)
        xx = x(z);%getting current x and y
        yy = y(z);
        if yy >= 1 && yy <= size(map,1) && xx >= 1 && xx <= size(map,2)
            if map(yy,xx) == 0%when current point is black
                penalties = penalties+6;%add penalty bias
            end
        end
    end
end
end

function [x,y] = bresLine(x1,x2,y1,y2)
ygradient = -abs(y2-y1);%getting x and y line gradient
xgradient = abs(x2-x1);
x = [];
y = [];
if y1>y2%checking which direction line goes in based on comparing x1 and y1 to x2 and y2, if 1>2 then the line goes in the reverse direction 
    yDirection = -1;
else
    yDirection = 1;
end
if x1>x2
    xDirection = -1;
else
    xDirection = 1;
end
lineGradient = xgradient + ygradient;%get full gradient of line
xPoint = x1;
yPoint = y1;

while true
    y(end+1) = yPoint;%setting a variable to current y
    x(end+1) = xPoint;%setting a variable to current x
    if y2 == yPoint && x2 == xPoint%checking for last point in line
        break
    end
    stepper = lineGradient + lineGradient;%creating a variable for stepping through points
    if stepper <= xgradient
        lineGradient = lineGradient + xgradient;
        yPoint = yPoint + yDirection;%move step in y direction if stepper is less than or equal to x gradient 
    end
    if stepper >= ygradient
        lineGradient = lineGradient + ygradient;
        xPoint = xPoint + xDirection;%same as above for x direction
    end
end
end

function selectedChrom = rouletteSelector(balance)%roulette selection
cumBalance = cumsum(balance);%get the cumulative sum of the values passed from fitnessCalc
roulette = rand();%random roulette chromosome
chromosomeChoice = -5;%value less than 0 to ensure nothing is accidentally picked
for i = 1 : length(cumBalance)
    if(cumBalance(i)>roulette)
        chromosomeChoice = i;%setting current index to the chromosome choice for later use
        break;
    end
end
selectedChrom = chromosomeChoice;%setting same chrom choice to selected chrom
end

function selectedChrom = rankSelector(fitnessCalc)
[~,sortedI] = sort(fitnessCalc,'descend');%sorting fitnesses in descending order
rank = 1:length(fitnessCalc);
balance = 1./rank;%get weights by dividing 1 by rank
selectedChrom = rouletteSelector(balance(sortedI));%running the new sorted fitnesses through roulette selection
end

function selectedChrom = tournamentSelector(fitnessCalc, population)
tournamentIndices = randperm(size(population, 1), 5);%randomly choose 5 indexes from population
tournamentFitness = fitnessCalc(tournamentIndices);%get fitness value of the indexes
[~, winnerIndex] = max(tournamentFitness);%get the index with the highest fitness value
selectedChrom = tournamentIndices(winnerIndex);%set the selected chromosome to the winner
end









